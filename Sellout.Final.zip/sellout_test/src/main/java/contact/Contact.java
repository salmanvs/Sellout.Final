package contact;

public class Contact {
	private int id;
	private String contact_us_name,contact_us_email,contact_us_message;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getContact_us_name() {
		return contact_us_name;
	}
	public void setContact_us_name(String contact_us_name) {
		this.contact_us_name = contact_us_name;
	}
	public String getContact_us_email() {
		return contact_us_email;
	}
	public void setContact_us_email(String contact_us_email) {
		this.contact_us_email = contact_us_email;
	}
	public String getContact_us_message() {
		return contact_us_message;
	}
	public void setContact_us_message(String contact_us_message) {
		this.contact_us_message = contact_us_message;
	}

}

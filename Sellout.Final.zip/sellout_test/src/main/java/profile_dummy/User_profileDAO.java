package profile_dummy;

import java.sql.Connection;


import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


import databaseConnection.*;
import profile_dummy.User_profileDAO;

public class User_profileDAO {
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(Databaseconnection.driverClass);
			con = DriverManager.getConnection(Databaseconnection.connectionUrl,Databaseconnection.username,Databaseconnection.password);
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;

	}


	 
		public static List<User_profile> getAllRecords() {
			List<User_profile> list = new ArrayList<User_profile>();

			try {
				Connection con = getConnection();
				PreparedStatement ps = con.prepareStatement("select * from user_details");
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					User_profile u = new User_profile();
					u.setId(rs.getInt("user_details_id"));
					u.setName(rs.getString(2));
					u.setMobile_number(rs.getString(3));
					u.setPlace(rs.getString(4));
					u.setEmail(rs.getString(5));
					u.setCountry(rs.getString(6));
					u.setState(rs.getString(7));
					list.add(u);
				}
			} catch (Exception e) {
				System.out.println(e);
			}
			return list;
		}

}

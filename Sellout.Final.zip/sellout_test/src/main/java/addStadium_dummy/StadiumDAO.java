package addStadium_dummy;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import databaseConnection.*;


public class StadiumDAO {
	public static Connection getConnection() {

		Connection con = null;
		try {
			Class.forName(Databaseconnection.driverClass);
			con = DriverManager.getConnection(Databaseconnection.connectionUrl,Databaseconnection.username,Databaseconnection.password);
		} catch (Exception e) {
			System.out.println(e);
		}
	
		return con;

}

public static int save(Stadium u) {
	int status = 0;
	try {
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("insert into add_stadium(add_stadium_stadium_name,add_stadium_location,add_stadium_total_seat_count,add_stadium_silver_seat_count,add_stadium_gold_seat_count,add_stadium_platinum_seat_count,add_stadium_silver_seat_price,add_stadium_gold_seat_price,add_stadium_platinum_seat_price) values(?,?,?,?,?,?,?,?,?)");
		ps.setString(1, u.getAdd_stadium_stadium_name());
		ps.setString(2, u.getAdd_stadium_location());
		ps.setString(3, u.getAdd_stadium_total_seat_count());
		ps.setString(4, u.getAdd_stadium_silver_seat_count());
		ps.setString(5, u.getAdd_stadium_gold_seat_count());
		ps.setString(6, u.getAdd_stadium_platinum_seat_count());
		ps.setString(7, u.getAdd_stadium_silver_seat_price());
		ps.setString(8, u.getAdd_stadium_gold_seat_price());
		ps.setString(9, u.getAdd_stadium_platinum_seat_price());
		status = ps.executeUpdate();
	} catch (Exception e) {
		System.out.println(e);
	}
	return status;
}

public static int update(Stadium u) {
	int status = 0;
	try {
		Connection con = getConnection();
		PreparedStatement ps = con
				.prepareStatement("update add_stadium set add_stadium_stadium_name=?,add_stadium_location=?,add_stadium_total_seat_count=?,add_stadium_silver_seat_count=?,add_stadium_gold_seat_count=?,add_stadium_platinum_seat_count=?,add_stadium_silver_seat_price=?,add_stadium_gold_seat_price=?,add_stadium_platinum_seat_price=? where id=?");
		ps.setString(1, u.getAdd_stadium_stadium_name());
		ps.setString(2, u.getAdd_stadium_location());
		ps.setString(3, u.getAdd_stadium_total_seat_count());
		ps.setString(4, u.getAdd_stadium_silver_seat_count());
		ps.setString(5, u.getAdd_stadium_gold_seat_count());
		ps.setString(6, u.getAdd_stadium_platinum_seat_count());
		ps.setString(7, u.getAdd_stadium_silver_seat_price());
		ps.setString(8, u.getAdd_stadium_gold_seat_price());
		ps.setString(9, u.getAdd_stadium_platinum_seat_price());
		ps.setInt(10, u.getId());
		status = ps.executeUpdate();
	} catch (Exception e) {
		System.out.println(e);
	}
	return status;
}

public static int delete(Stadium u) {
	int status = 0;
	try {
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("delete from register where id=?");
		ps.setInt(1, u.getId());
		status = ps.executeUpdate();
	} catch (Exception e) {
		System.out.println(e);
	}

	return status;
}

public static List<Stadium> getAllRecords() {
	List<Stadium> list = new ArrayList<Stadium>();

	try {
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("select * from add_stadium");
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			Stadium u = new Stadium();
			u.setId(rs.getInt("id"));
			u.setAdd_stadium_stadium_name("stadiumname");
			u.setAdd_stadium_location("location");
			u.setAdd_stadium_total_seat_count("totalseatcount");
			u.setAdd_stadium_silver_seat_count("silverseatcount");
			u.setAdd_stadium_gold_seat_count("goldseatcount");
			u.setAdd_stadium_platinum_seat_count("platinumseatcount");
			u.setAdd_stadium_silver_seat_price("silverseatprice");
			u.setAdd_stadium_gold_seat_price("goldseatprice");
			u.setAdd_stadium_platinum_seat_price("platinumseatprice");
			list.add(u);
		}
	} catch (Exception e) {
		System.out.println(e);
	}
	return list;
}

public static Stadium getRecordById(int id) {
	Stadium u = null;
	try {
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("select * from register where id=?");
		ps.setInt(1, id);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			u = new Stadium();
			u.setId(rs.getInt("id"));
			u.setAdd_stadium_stadium_name("stadiumname");
			u.setAdd_stadium_location("location");
			u.setAdd_stadium_total_seat_count("totalseatcount");
			u.setAdd_stadium_silver_seat_count("silverseatcount");
			u.setAdd_stadium_gold_seat_count("goldseatcount");
			u.setAdd_stadium_platinum_seat_count("platinumseatcount");
			u.setAdd_stadium_silver_seat_price("silverseatprice");
			u.setAdd_stadium_gold_seat_price("goldseatprice");
			u.setAdd_stadium_platinum_seat_price("platinumseatprice");
		}
	} catch (Exception e) {
		System.out.println(e);
	}
	return u;
}
}

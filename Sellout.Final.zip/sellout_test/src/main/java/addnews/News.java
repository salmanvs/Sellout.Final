package addnews;

public class News {
	private int id;
	private String add_news_news;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAdd_news_news() {
		return add_news_news;
	}
	public void setAdd_news_news(String add_news_news) {
		this.add_news_news = add_news_news;
	} 
	
	

}

package addnews;

import java.sql.*;
import databaseConnection.*;

public class NewsDao {
	
		public static Connection getConnection() {

			Connection con = null;
			try {
				Class.forName(Databaseconnection.driverClass);
				con = DriverManager.getConnection(Databaseconnection.connectionUrl,Databaseconnection.username,Databaseconnection.password);
			} catch (Exception e) {
				System.out.println(e);
			}
		
			return con;

	}
		public static int save(News u) {
			int status = 0;
			try {
				Connection con = getConnection();
				PreparedStatement ps = con.prepareStatement("insert into add_news(add_news_news) values(?)");
				ps.setString(1,u.getAdd_news_news());
				
				status = ps.executeUpdate();
			} catch (Exception e) {
				System.out.println(e);
			}
			return status;
		}

		}
package upload;

import java.sql.Blob;

public class Upload_been {
	private int id;
	private Blob user_details_add_profile_picture;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Blob getUser_details_add_profile_picture() {
		return user_details_add_profile_picture;
	}
	public void setUser_details_add_profile_picture(Blob user_details_add_profile_picture) {
		this.user_details_add_profile_picture = user_details_add_profile_picture;
	}

}

package profile;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;



import profile.Profile;
import databaseConnection.Databaseconnection;

public class ProfileDao {
	public static Connection getConnection() {

		Connection con = null;
		try {
			Class.forName(Databaseconnection.driverClass);
			con = DriverManager.getConnection(Databaseconnection.connectionUrl,Databaseconnection.username,Databaseconnection.password);
		} catch (Exception e) {
			System.out.println(e);
		}
	
		return con;

}
	public static int save(Profile u) {
		int status = 0;
		try {
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement("insert into user_details(user_details_name,user_details_mobile_number,user_details_place,user_details_email,user_details_country,user_details_state) values(?,?,?,?,?,?)");
			ps.setString(1,u.getUser_details_name());
			ps.setString(2,u.getUser_details_mobile_number());
			ps.setString(3,u.getUser_details_place());
			ps.setString(4,u.getUser_details_email());
			ps.setString(5,u.getUser_details_country());
			ps.setString(6,u.getUser_details_state());
			
			status = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}
	
}

package matchdetails;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import matchdetails.Matchdetails;
import databaseConnection.Databaseconnection;

public class MatchdetailsDao {
	public static Connection getConnection() {

		Connection con = null;
		try {
			Class.forName(Databaseconnection.driverClass);
			con = DriverManager.getConnection(Databaseconnection.connectionUrl, Databaseconnection.username,
					Databaseconnection.password);
		} catch (Exception e) {
			System.out.println(e);
		}

		return con;

	}

	public static int save(Matchdetails u) {
		int status = 0;
		try {
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement(
					"insert into match_details(match_details_match_name,match_details_stadium_name,match_details_match_date,match_details_match_time,match_details_match_discription) values(?,?,?,?,?)");
			ps.setString(1, u.getMatch_details_match_name());
			ps.setString(2, u.getMatch_details_stadium_name());
			ps.setString(3, u.getMatch_details_match_date());
			ps.setString(4, u.getMatch_details_match_time());
			ps.setString(5, u.getMatch_details_match_discription());
			status = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}

}
